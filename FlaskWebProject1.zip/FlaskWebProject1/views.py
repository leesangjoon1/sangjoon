"""
Routes and views for the flask application.
"""

from datetime import datetime
from flask import render_template
from FlaskWebProject1 import app

@app.route('/')
@app.route('/home')
def home():
    """Renders the home page."""
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now().year,
    )
@app.route('/contact')
def contact():
    """Renders the contact page."""
    return render_template(
        'contact.html',
        title='Contact',
        year=datetime.now().year,
        message='Your contact page.'
    )
@app.route('/projects')
def projects():
    """Renders the project page."""
    return render_template(
        'projects.html',
        title='Projects',
        year=datetime.now().year,
        message='Ongoing and Completed Projects'
    )
@app.route('/gallery')
def gallery():
    """Renders the Gallery page."""
    return render_template(
        'gallery.html',
        title='Gallery',
        year=datetime.now().year,
        message='Some of my cute Memories'
    )
@app.route('/about')
def about():
    return render_template(
        'about.html',
        title='About Me',
        year=datetime.now().year,
        message='About me'
    )